# -*- coding: utf-8 -*-

from . import hr_department
from . import hr_employee
from . import purchase_order
from . import purchase_requisition
from . import purchase_requisition_line
from . import stock_picking

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
