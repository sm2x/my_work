# -*- coding: utf-8 -*-

from odoo import models, fields, api


# class ommat_catalogue(models.Model):
#     _name = 'ommat.catalogue'
#
#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()

