{
    'name': 'Powered By GIT',
    'version': '1.1',
    'summary': 'Change  Powered By Odoo To Powered By GIT',
    'description': """
        """,
    'author': "GIT",
    'category': 'IT',
    'website': 'http://www.git-eg.com',
    'depends': [],
    'data': [
        'views/test.xml',



             ],
    'demo': [],
    'qweb': [],
    'installable': True,
    'auto_install': False,
    'sequence': 1
}

