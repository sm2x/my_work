# -*- encoding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import sprogroup_purchase_request
from . import vendor_model
from . import products
from . import stock_castom
