# -*- coding: utf-8 -*-

from odoo import models, fields, api,_
from odoo.exceptions import UserError
from odoo.tools import float_is_zero


class NaseejStockMoveLine(models.Model):
    _inherit = 'stock.move.line'

    # move_line = fields.Many2one('stock.move.line')
    old_lot = fields.Char('Old Lot')
    old_lot2 = fields.Char('Old Lot2')

class NaseejInventory(models.Model):
    _inherit = 'stock.picking.type'

    internal_loc = fields.Boolean('Is Internal?')
    internal_location = fields.Many2one('stock.location', string='Destination Transfer Location')
    return_location = fields.Many2one('stock.location', string='Return Transfer Location')

    internal_operation_type = fields.Many2one('stock.picking.type', string='Internal Operation Type')
    nas_return_operation_type = fields.Many2one('stock.picking.type', string='NReturn Operation Type')


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    pack_picking_id = fields.Many2one('stock.picking', 'Pack Picking')
    return_picking_id = fields.Many2one('stock.picking', 'Return Picking')
    show_button_generate = fields.Boolean(string="show", default=True)
    after_click_button_generate = fields.Boolean(string="click", default=True)
    check_operation_type = fields.Boolean(string="click", default=True)

    @api.onchange('picking_type_id')
    def _check_operation_type(self):
        for pick in self:
            if pick.picking_type_id.code != 'internal':
                self.check_operation_type = False

    @api.onchange('picking_type_id')
    def show_generate_btn(self):
        for pick in self:
            if not pick.picking_type_id.internal_loc:
                self.show_button_generate = False

    def generate_receipt_order(self):
        for rec in self:
            pick = rec.copy()
            internal_picking_type = rec.picking_type_id.internal_operation_type
            pick_dest_location = rec.picking_type_id.internal_location
            pick.write({'picking_type_id': internal_picking_type.id,
                        'location_id': rec.location_dest_id.id,
                        'location_dest_id': pick_dest_location.id, })
            for line in pick.move_lines:
                line.write({
                    'picking_type_id': internal_picking_type.id,
                    'picking_id': pick.id,
                    'location_id': rec.location_dest_id.id,
                    'location_dest_id': pick_dest_location.id

                })


            pick.action_confirm()
            pick.action_assign()
            pick.show_button_generate = False
            rec.after_click_button_generate = False
            rec.pack_picking_id = pick.id

    def prepare_move_line_ids(self):
        for rec in self:

            m_lines= rec.move_lines.move_line_ids
            for m_line in m_lines:
                old_lot = rec.move_lines.move_line_ids.old_lot2
                m_line.write({
                    'old_lot': old_lot})

    def generate_return_picking(self):
        for rec in self:

            pick = rec.copy()
            return_picking_type = rec.picking_type_id.nas_return_operation_type
            # return_loc = rec.location_dest_id.copy()
            # return_loc.write({
            #     'usage': 'internal'
            # })
            pick.write({
                'picking_type_id': return_picking_type.id,
                'origin': _("Return of %s") % rec.name,
                'location_id': rec.location_dest_id.id,
                'location_dest_id': rec.location_id.id
                })

            for line in pick.move_lines:
                line.write({
                    'picking_type_id': return_picking_type.id,
                    'picking_id': pick.id,
                    'location_id': rec.location_dest_id.id,
                    'location_dest_id': rec.location_id.id,
                    # 'old_lot': line.lot_id.lot_name
                })
                for m_line in pick.move_lines.move_line_ids:
                    old_lot = rec.move_lines.move_line_ids.old_lot2
                    m_line.write({
                        'old_lot': old_lot})

            pick.action_confirm()
            pick.action_assign()
            # pick.button_validate()
            # pick.show_button_generate = False
            # self.after_click_button_generate = False
            rec.return_picking_id = pick.id

